# Phoenix Smart Locator AI

A Python package that automatically generates Playwright and Selenium locators from HTML files or URLs, with stability scoring, framework compatibility detection, and ready-to-use Page Object Model exports.

## Features

- **DOM Scanning**: Extract interactable elements from HTML files or live URLs
- **Multi-Framework Support**: Generate locators for Playwright, Selenium, or both
- **Stability Scoring**: Automatic scoring (1-10) and categorization (High/Medium/Low)
- **Smart Locator Generation**: CSS selectors, XPath, and Playwright role/text selectors
- **Dynamic Detection**: Flag unstable attributes (UUIDs, timestamps, dynamic IDs)
- **Duplicate Detection**: Identify duplicate IDs and names
- **Code Generation**: Ready-to-use code snippets for each framework
- **Page Object Export**: Generate complete Page Object classes
- **Optional Validation**: Real-browser validation with authentication support
- **Optional AI Enrichment**: Gemini AI-powered analysis and recommendations

## Installation

### From Source (Development)

```bash
# Clone the repository
git clone https://github.com/shaktitrigent/Phoenix-SmartLocatorAI.git
cd Phoenix-SmartLocatorAI

# Install in development mode
pip install -e .

# Or install with optional dependencies
pip install -e ".[all]"  # Includes Gemini and Playwright
pip install -e ".[gemini]"  # Gemini only
pip install -e ".[playwright]"  # Playwright only
```

### Build and Install Wheel

```bash
# Build the package
python -m build

# Install from wheel
pip install dist/phoenix_smartlocatorai-1.0.0-py3-none-any.whl
```

### Dependencies

**Required:**
- `beautifulsoup4>=4.14.0`
- `requests>=2.31.0`
- `lxml>=6.0.0`
- `soupsieve>=2.8`

**Optional:**
- `google-generativeai>=0.3.0` (for Gemini AI enrichment)
- `playwright>=1.40.0` (for JavaScript rendering and validation)

## Quick Start

### CLI Usage

After installation, use the `phoenix-locgen` command:

```bash
# Generate locators from HTML file
phoenix-locgen --input page.html --frameworks Playwright,Selenium

# Generate from URL
phoenix-locgen --input https://example.com --frameworks Playwright --output ./out

# Filter by minimum stability
phoenix-locgen --input page.html --frameworks Selenium --min-stability High

# Use JavaScript rendering (for dynamic pages)
phoenix-locgen --input https://example.com --frameworks Playwright --js

# Enable validation (requires Playwright)
phoenix-locgen --input https://example.com --frameworks Playwright --validate

# Enable Gemini AI enrichment
phoenix-locgen --input page.html --frameworks Playwright,Selenium --gemini
```

### Python API Usage

```python
from phoenix_smartlocatorai import generate_locators_from_dom

# Generate locators from HTML file
result = generate_locators_from_dom(
    input_html_or_url="page.html",
    frameworks=["Playwright", "Selenium"],
    output_dir="./out",
    class_name="ProductPage",
    min_stability="Medium",
)

print(f"Generated files: {result}")
# {
#     "locators_json": "./out/locators.json",
#     "playwright_pom": "./out/ProductPage_Playwright.py",
#     "selenium_pom": "./out/ProductPage_Selenium.py"
# }
```

### From HTML String

```python
from phoenix_smartlocatorai import generate_locators_from_dom

html = """
<html>
    <body>
        <button id="submit-btn">Submit</button>
        <input type="text" name="username" />
    </body>
</html>
"""

result = generate_locators_from_dom(
    input_html_or_url=html,
    frameworks=["Selenium"],
    output_dir="./out",
)
```

### From URL

```python
from phoenix_smartlocatorai import generate_locators_from_dom

result = generate_locators_from_dom(
    input_html_or_url="https://example.com",
    frameworks=["Playwright", "Selenium"],
    output_dir="./out",
    use_js=True,  # Render JavaScript
    validate=True,  # Validate in real browser
)
```

## Output Files

### `locators.json`

Structured JSON with metadata, summary statistics, and all locators:

```json
{
  "metadata": {
    "generated_at": "2025-11-20T12:00:00",
    "source": "https://example.com",
    "total_elements": 10,
    "total_locators": 25,
    "frameworks": ["playwright", "selenium"],
    "min_stability": "Medium",
    "validated": false,
    "ai_enriched": false,
    "class_name": "ProductPage"
  },
  "summary": {
    "total_elements": 10,
    "total_locators": 25,
    "locator_distribution": {
      "css": 15,
      "xpath": 8,
      "role": 2
    },
    "framework_split": {
      "playwright": 10,
      "selenium": 8,
      "both": 7
    },
    "stability": {
      "high": 12,
      "medium": 10,
      "low": 3
    }
  },
  "locators": [
    {
      "custom_name": "SubmitButton",
      "locator_type": "CSS Selector",
      "locator_value": "#submit-btn",
      "stability": "High",
      "stability_score": 9,
      "automation_tool": "Both",
      "playwright_code": "page.locator('#submit-btn').click()",
      "selenium_code": "driver.find_element(By.CSS_SELECTOR, '#submit-btn').click()",
      "dynamic": false,
      "duplicate": false,
      "warnings": []
    }
  ]
}
```

### `page.py` (Single Framework)

When only one framework is specified, a generic `page.py` is generated:

```python
from playwright.sync_api import Page

class Page:
    def __init__(self, page: Page):
        self.submit_button = page.locator('#submit-btn')
        self.username_input = page.locator('#username-input')
```

### `<ClassName>_Playwright.py` and `<ClassName>_Selenium.py`

Framework-specific Page Object classes:

**Playwright:**
```python
from playwright.sync_api import Page

class ProductPage:
    def __init__(self, page: Page):
        self.submit_button = page.locator('#submit-btn')
        self.username_input = page.locator('#username-input')
```

**Selenium:**
```python
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webdriver import WebDriver

class ProductPage:
    def __init__(self, driver: WebDriver):
        self.submit_button = driver.find_element(By.CSS_SELECTOR, '#submit-btn')
        self.username_input = driver.find_element(By.CSS_SELECTOR, '#username-input')
```

## Authenticated Validation

Validate locators on pages that require authentication:

### Option A: Storage State (Playwright)

```bash
phoenix-locgen \
  --input https://your.app/page \
  --frameworks Playwright \
  --validate \
  --auth-storage-state path/to/storage_state.json
```

### Option B: Scripted Login

```bash
phoenix-locgen \
  --input https://your.app/protected \
  --frameworks Playwright \
  --validate \
  --auth-url https://your.app/login \
  --auth-user USER \
  --auth-pass PASS \
  --user-selector "#username" \
  --pass-selector "#password" \
  --submit-selector "button[type='submit']" \
  --auth-wait-selector "a.main-menu"
```

## CLI Reference

```bash
phoenix-locgen --help
```

**Key Arguments:**
- `--input, -i`: Input HTML file path or URL (required)
- `--frameworks, -f`: Comma-separated frameworks: `Playwright,Selenium` (default: `Playwright,Selenium`)
- `--output, -o`: Output directory (default: current directory)
- `--class-name, -c`: Page Object class name (default: `Page`)
- `--min-stability, -s`: Filter by stability: `High`, `Medium`, `Low`
- `--js`: Use Playwright to render JavaScript (for URL inputs)
- `--validate`: Validate locators in real browser (requires Playwright)
- `--gemini`: Enable Gemini AI enrichment (requires `GOOGLE_API_KEY`)

**Authentication Options (for `--validate`):**
- `--auth-storage-state`: Playwright storage state JSON path
- `--auth-url`: Login URL
- `--auth-user`: Username
- `--auth-pass`: Password
- `--user-selector`: Username field selector
- `--pass-selector`: Password field selector
- `--submit-selector`: Submit button selector
- `--auth-wait-selector`: Element to wait for after login
- `--auth-wait-url-contains`: URL substring to wait for after login

## API Reference

### `generate_locators_from_dom()`

```python
def generate_locators_from_dom(
    input_html_or_url: Union[str, Path],
    frameworks: Optional[List[str]] = None,
    output_dir: Union[str, Path] = ".",
    class_name: str = "Page",
    min_stability: Optional[str] = None,
    use_js: bool = False,
    validate: bool = False,
    auth_opts: Optional[Dict[str, Any]] = None,
    use_gemini: bool = False,
) -> Dict[str, str]:
```

**Parameters:**
- `input_html_or_url`: Path to HTML file, HTML string, or URL
- `frameworks`: List of frameworks (`["Playwright", "Selenium"]`) or `None` for both
- `output_dir`: Directory for output files (default: current directory)
- `class_name`: Name for Page Object class (default: `"Page"`)
- `min_stability`: Filter by minimum stability (`"High"`, `"Medium"`, `"Low"`)
- `use_js`: Use Playwright to render JavaScript (for URL inputs)
- `validate`: Validate locators in real browser (URL inputs only)
- `auth_opts`: Authentication options dictionary (for validation)
- `use_gemini`: Enable Gemini AI enrichment

**Returns:**
Dictionary with paths to generated files:
```python
{
    "locators_json": "path/to/locators.json",
    "page_py": "path/to/page.py",  # Only if single framework
    "playwright_pom": "path/to/Page_Playwright.py",  # If Playwright requested
    "selenium_pom": "path/to/Page_Selenium.py",  # If Selenium requested
}
```

## Testing

Run tests with pytest:

```bash
# Install test dependencies
pip install pytest

# Run all tests
pytest tests/

# Run specific test file
pytest tests/test_core.py

# Run with verbose output
pytest -v tests/
```

## Project Structure

```
Phoenix-SmartLocatorAI/
├── src/
│   └── phoenix_smartlocatorai/
│       ├── __init__.py          # Package initialization and public API
│       ├── core.py              # Main API (generate_locators_from_dom)
│       ├── cli.py               # CLI tool (phoenix-locgen)
│       ├── dom_scanner.py       # DOM scanning and locator generation
│       └── page_object_exporter.py  # Page Object Model generation
├── tests/
│   ├── __init__.py
│   ├── test_core.py            # Core API tests
│   └── test_dom_scanner.py     # DOM scanner tests
├── pyproject.toml              # Package configuration
├── README.md                   # This file
└── LICENSE                     # MIT License
```

## Examples

### Example 1: Basic HTML File

```bash
phoenix-locgen --input test.html --frameworks Playwright,Selenium --class-name LoginPage
```

### Example 2: URL with JavaScript

```bash
phoenix-locgen --input https://example.com --frameworks Playwright --js --output ./results
```

### Example 3: High Stability Only

```bash
phoenix-locgen --input page.html --frameworks Selenium --min-stability High
```

### Example 4: With Validation

```bash
phoenix-locgen \
  --input https://example.com \
  --frameworks Playwright \
  --validate \
  --auth-url https://example.com/login \
  --auth-user admin \
  --auth-pass password \
  --user-selector "#username" \
  --pass-selector "#password" \
  --submit-selector "button[type='submit']"
```

## License

MIT License (see `LICENSE` file).

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Support

For issues, questions, or contributions, please visit:
https://github.com/shaktitrigent/Phoenix-SmartLocatorAI
